

pref("general.useragent.locale", "en-US");
